//
//  CityName.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 31/05/22.
//

import Foundation

//All CityName static latitude and longitude

struct CityName {
    static let Gothenburg = (57.7072, 11.9668)
    static let Stockholm = (59.3293, 18.0686)
    static let MountainView = (37.3861, -122.0839)
    static let London =  (51.5085, -0.1257)
    static let NewYork = (40.7128, -74.0060)
    static let Berlin = (52.5244, 13.4105)
}


//  var cityModelData: [(latData: Double, longData: Double)] = [(57.7072, 11.9668), (59.3293, 18.0686), (37.3861, -122.0839), (51.5085, -0.1257), (40.7128, -74.0060), (52.5244, 13.4105)]
