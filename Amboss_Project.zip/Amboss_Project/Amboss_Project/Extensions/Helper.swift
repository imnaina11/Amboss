//
//  Helper.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 26/05/22.
//

import Foundation
import UIKit

extension UIImageView {
    func load(url:URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}
