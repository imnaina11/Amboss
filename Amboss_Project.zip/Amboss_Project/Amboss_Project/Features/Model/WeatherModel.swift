//
//  WeatherModel.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 23/05/22.
//

import Foundation
struct WeatherModel: Codable {
    let name: String
    let main: mainData
    let weather: [weatherData]
}

struct mainData: Codable {
    let temp: Double
    let temp_min: Double
    let temp_max: Double
}

struct weatherData: Codable {
    let main: String
    let icon: String
}


struct showWeatherModel {
    var cityName: String
    var currentTemp: String
    var icon: String
    var desc: String
    var minTemp: String
    var maxTemp: String
}


struct cityName {
    let lat: Double
    let long: Double
}
