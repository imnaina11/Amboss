//
//  CityTableViewCell.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 26/05/22.
//

import UIKit

class CityTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageViewIcon: UIImageView!
    @IBOutlet weak var lblCityName: UILabel!
    @IBOutlet weak var lblCurrentWeather: UILabel!
    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblMinTemp: UILabel!
    @IBOutlet weak var lblMaxTemp: UILabel!
    @IBOutlet weak var stackViewTemp: UIStackView!
    @IBOutlet weak var btnMore: UIButton!
    
    var delegate: DidPressButton?
    
    var show : Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    func setData(model: showWeatherModel){
        self.lblCityName.text = model.cityName
        if let url = URL(string: "http://openweathermap.org/img/wn/\(model.icon)@2x.png") {
            self.imageViewIcon.load(url: url)
        }
        self.lblCurrentWeather.text = ("\(model.currentTemp) °C")
        self.lblDesc.text = model.desc
        self.lblMinTemp.text = "Min : \(model.minTemp) °C"
        self.lblMaxTemp.text = "Max : \(model.maxTemp) °C"
    }
    
    
    @IBAction func onClickMore(_ sender: UIButton) {
        self.show = !self.show
        delegate?.didPressMoreButton(index: sender.tag, isExpanded: self.show)
    }
    
    func hideStackView() {
        self.btnMore.setTitle("more", for: .normal)
        self.stackViewTemp.isHidden = true
        self.stackViewTemp.layer.cornerRadius = 10
    }
    
    func showStackView(){
        self.btnMore.setTitle("less", for: .normal)
        self.stackViewTemp.isHidden = false
        self.stackViewTemp.layer.cornerRadius = 10
    }
    
}
