//
//  AmbossViewController.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 24/05/22.
//

import RxSwift
import UIKit

protocol DidPressButton {
    func didPressMoreButton(index: Int, isExpanded: Bool)
}

class AmbossViewController: UIViewController, DidPressButton {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblTitle: UILabel!
    
    var arrIndexPaths = NSMutableArray()
    let viewModel = AmbossViewModel()
    let disposeBag = DisposeBag()
    
    var weatherToShow: [showWeatherModel] = []
    var selectedCells: [Int] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        subscribeObservers()
        viewModel.getWeatherResponse()
        
        let tableViewNib = UINib(nibName: "CityTableViewCell", bundle: nil)
        tableView.register(tableViewNib, forCellReuseIdentifier: "Ambosstableviewidentifier")
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    func subscribeObservers(){
        
        viewModel.dataModelSubj.subscribe(onNext: { model in
            self.weatherToShow = model
            self.selectedCells.removeAll()
            self.tableView.reloadData()
        }).disposed(by: disposeBag)
        
    }
    
    func didPressMoreButton(index: Int, isExpanded: Bool) {
        if isExpanded {
            self.selectedCells.append(index)
        } else
        {
            if self.selectedCells.contains(index) {
                if let indToRemove = selectedCells.firstIndex(of: index){
                    self.selectedCells.remove(at: indToRemove)
                }
            }
        }
        self.tableView.reloadData()
    }
    
    
}
extension AmbossViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.weatherToShow.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CityTableViewCell = self.tableView.dequeueReusableCell(withIdentifier: "Ambosstableviewidentifier") as! CityTableViewCell
        cell.delegate = self
        cell.btnMore.tag = indexPath.row
        if weatherToShow.count != 0 {
            if self.selectedCells.contains(indexPath.row) {
                cell.showStackView()
                cell.show = true
            } else {
                cell.hideStackView()
                cell.show = false
            }
            cell.setData(model: weatherToShow[indexPath.row])
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if self.selectedCells.contains(indexPath.row)
        {
            return 150
        } else {
            return 100
            
        }
    }
}


