//
//  Amboss_ProjectTests.swift
//  Amboss_ProjectTests
//
//  Created by Naina Gupta on 23/05/22.
//

import XCTest

@testable import Amboss_Project

class Amboss_ProjectTests: XCTestCase {
    
    var viewModel = AmbossViewModel()
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testAPICall() throws {
        // This test if all the Dispatch Group functions responded and returned the result successfully.
        
        var modelData: [showWeatherModel]?
        let expectation = self.expectation(description: "API Called Successfully")
        
        viewModel.getWeatherResponse()
        
        viewModel.dataModelSubj.subscribe(onNext: {  model in
            modelData = model
            expectation.fulfill()
        })
        
        waitForExpectations(timeout: 10 , handler: nil)
        XCTAssertTrue(modelData != nil)
        
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
