//
//  AmbossViewModel.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 23/05/22.
//

import Foundation
import RxSwift
import Alamofire

class AmbossViewModel {
    
    let networkManager = NetworkManager()
    let rxBag = DisposeBag()
    
    var nameSubj = PublishSubject<[String]>()
    var tempSubj = PublishSubject<Double>()
    var iconSubj = PublishSubject<String>()
    
    var dataModelSubj = PublishSubject<[showWeatherModel]>()
    
    typealias CompletionHandler = (_ success:[String]) -> Void
    var cityArray = Set<String>()
    
    
    func getWeatherResponse()  {
        
        var dataModel: [showWeatherModel] = []
        let group = DispatchGroup()
        
        let _ = DispatchQueue.global(qos: .userInitiated)
        
        //1
        group.enter()
        self.networkManager.getWeatherResponse(lat: CityName.Gothenburg.0, long: CityName.Gothenburg.1){ response in
            if let icon = response.weather.first?.icon, let desc = response.weather.first?.main {
                dataModel.append(showWeatherModel(cityName: response.name, currentTemp: String(format: "%.2f", response.main.temp - 273.15), icon: icon, desc: desc, minTemp: String(format: "%.2f", (response.main.temp_min - 273.15)), maxTemp: String(format: "%.2f", (response.main.temp_max - 273.15))))
            }
            group.leave()
        }
        
        //2
        group.enter()
        self.networkManager.getWeatherResponse(lat: CityName.Stockholm.0, long: CityName.Stockholm.1){ response in
            if let icon = response.weather.first?.icon, let desc = response.weather.first?.main  {
                dataModel.append(showWeatherModel(cityName: response.name, currentTemp: String(format: "%.2f", response.main.temp -  273.15), icon: icon, desc: desc, minTemp: String(format: "%.2f", (response.main.temp_min - 273.15) ), maxTemp: String(format: "%.2f", (response.main.temp_max - 273.15))))
            }
            group.leave()
        }
        
        //3
        group.enter()
        self.networkManager.getWeatherResponse(lat: CityName.MountainView.0, long: CityName.MountainView.1){ response in
            if let icon = response.weather.first?.icon, let desc = response.weather.first?.main  {
                dataModel.append(showWeatherModel(cityName: response.name, currentTemp: String(format: "%.2f", response.main.temp -  273.15), icon: icon, desc: desc, minTemp: String(format: "%.2f", (response.main.temp_min - 273.15)), maxTemp: String(format: "%.2f", (response.main.temp_max - 273.15) )))
            }
            group.leave()
        }
        
        
        //4
        group.enter()
        self.networkManager.getWeatherResponse(lat: CityName.London.0, long: CityName.London.1){ response in
            if let icon = response.weather.first?.icon, let desc = response.weather.first?.main  {
                dataModel.append(showWeatherModel(cityName: response.name, currentTemp: String(format: "%.2f", response.main.temp - 273.15), icon: icon, desc: desc, minTemp: String(format: "%.2f",(response.main.temp_min - 273.15)), maxTemp: String(format: "%.2f", (response.main.temp_max - 273.15))))
            }
            group.leave()
            
        }
        
        //5
        group.enter()
        self.networkManager.getWeatherResponse(lat: CityName.NewYork.0, long: CityName.NewYork.1){ response in
            if let icon = response.weather.first?.icon, let desc = response.weather.first?.main  {
                dataModel.append(showWeatherModel(cityName: response.name, currentTemp: String(format: "%.2f", response.main.temp - 273.15), icon: icon, desc: desc, minTemp: String(format: "%.2f", (response.main.temp_min - 273.15)), maxTemp: String(format: "%.2f", (response.main.temp_max - 273.15))))
            }
            group.leave()
            
        }
        
        //6
        group.enter()
        self.networkManager.getWeatherResponse(lat: CityName.Berlin.0, long: CityName.Berlin.1){ response in
            if let icon = response.weather.first?.icon, let desc = response.weather.first?.main  {
                dataModel.append(showWeatherModel(cityName: response.name, currentTemp: String(format: "%.2f", response.main.temp -  273.15), icon: icon, desc: desc, minTemp: String(format: "%.2f", response.main.temp_min -  273.15), maxTemp: String(format: "%.2f", (response.main.temp_max -  273.15))))
            }
            group.leave()
        }
        
        
        group.notify(queue: DispatchQueue.main){
            print(dataModel)
            self.dataModelSubj.onNext(dataModel)
        }
        
    }
}

