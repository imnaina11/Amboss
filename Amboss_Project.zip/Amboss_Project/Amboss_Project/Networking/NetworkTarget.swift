//
//  NetworkTarget.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 23/05/22.
//

import Foundation
import Moya
import UIKit

let apiKey = "1f89da47fe4d0be6bbbf376af70bdb58"

internal enum NetworkTarget {
    case getWeatherForecastForCity(lat:Double, long:Double)
}

extension NetworkTarget : TargetType {
    
    var baseURL: URL {
        return URL(string: "https://api.openweathermap.org")!
    }
    
    var path: String {
        switch self {
        case .getWeatherForecastForCity:
            return "/data/2.5/weather"
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return Data()
    }
    
    var queryParams: [String: Any?] {
        switch self {
        case .getWeatherForecastForCity(let lat, let long):
            let params: [String: Any?] = [
                "lat": lat,
                "lon": long,
                "appid" : apiKey ]
            return params
        }
    }
    
    var task: Task {
        switch self {
        case .getWeatherForecastForCity:
            let qParams : [String: Any] = queryParams.compactMapValues{$0}
            return Task.requestParameters(parameters: qParams as [String : Any], encoding: URLEncoding.queryString)
        }
    }
    
    var headers: [String: String]? {
        return [:]
    }
}
