//
//  NetworkProvider.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 23/05/22.
//

import Foundation
import Moya

internal class NetworkProvider: MoyaProvider<NetworkTarget> {
    
    fileprivate class func endpointClosure(for target: NetworkTarget) -> Endpoint {
        
        let headers: [String: String] = [
            "Content-Type": "application/json",
        ]
        
        return Endpoint(
            url: target.baseURL.appendingPathComponent(target.path).absoluteString,
            sampleResponseClosure: { .networkResponse(200, target.sampleData) },
            method: target.method,
            task: target.task,
            httpHeaderFields: headers
        )
    }
}
