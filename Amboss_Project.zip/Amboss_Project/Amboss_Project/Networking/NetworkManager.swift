//
//  NetworkManager.swift
//  Amboss_Project
//
//  Created by Naina Gupta on 23/05/22.
//

import Foundation
import Moya
import UIKit

class NetworkManager {
    
    private let provider = NetworkProvider()
    
    //MARK Get Issues  from API
    func getWeatherResponse(lat:Double, long: Double, completion:@escaping (_ response:WeatherModel) -> Void) {
        let _ =  provider.request(.getWeatherForecastForCity(lat: lat, long: long), completion: { (result) in
            switch result {
            case .success(let response):
                let decoder = JSONDecoder()
                do {
                    let responseData = try decoder.decode(WeatherModel.self, from: response.data)
                    debugPrint(responseData)
                    completion(responseData)
                }
                catch {
                    do {
                        let errorData = try decoder.decode(WeatherModel.self, from: response.data)
                        debugPrint("Error here while api call \(errorData)")
                    }
                    catch let error {
                        debugPrint(error)
                    }
                }
                break
            case .failure(let error):
                debugPrint("Error found : \(error)")
                break
            }
        })
    }
    
}
